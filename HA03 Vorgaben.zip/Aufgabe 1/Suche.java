public class Suche  {    
    // Suchmethode
    // TODO

}
